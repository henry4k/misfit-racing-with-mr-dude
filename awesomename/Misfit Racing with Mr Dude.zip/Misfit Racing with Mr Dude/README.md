Special Thanks to all who played the game. We hope you had as much fun as we had making it.

Production, Programming, Design: Dominik Reitz

Graphics : Henry Kielmann

Thanks also to Sven Jütte. Without him and his help the project wouldn't even have started.

External Assets:
-Fungus https://fungusgames.com/
-Save Game Free - Gold Update https://assetstore.unity.com/packages/tools/input-management/save-game-free-gold-update-81519

Font:
-Pixel Operator by Jayvee Enaguas (HarvettFox96), licensed under a Creative Commons Zero (CC0) 1.0. © 2009-2018
https://www.dafont.com/pixel-operator.font

Sound Effects:
-Engine Sound	https://assetstore.unity.com/packages/audio/sound-fx/engines-123836
-UI Sounds	https://assetstore.unity.com/packages/audio/sound-fx/free-casual-game-sfx-pack-54116

-Bell Blip		https://freesound.org/people/looppool/sounds/13119/
-Airhorn		https://freesound.org/people/jacksonacademyashmore/sounds/414208/
-CashRegister	https://freesound.org/people/CapsLok/sounds/184438/
-Screwdriver	https://freesound.org/people/jandobes97/sounds/379476/

Music:
-Battle for Honour by YouFulca
-Are you kidding by YouFulca
-Victory Jingle by YouFulca
-GameOver Jingle by YouFulca	
https://wingless-seraph.net/en/index.html

-Just Chill by Aaron Krogh

Game was made for Game Off 2018
Hosted by GitHub, Lee Reilly · #GitHubGameOff
